package TestCases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.WorkFlow.Pages.HomePage;
import com.WorkFlow.TestBase.TestBase;

public class CalculatorServiceTest extends TestBase{

	HomePage homepage;
	
	public CalculatorServiceTest() {
		super();
	}
	
	@BeforeTest
	public void setup() {
		intialization();
	       
	}
	
	@AfterTest
	public void driverclosewindow() {
		driverClose();
	}
	
	//Calculator Service Validation Test 
	@Test (priority=1)
	public void ValidateCalService() {
		
		   HomePage homepage = new HomePage();
	       homepage.CALCULATORSERVICE("4");   
	       String t = "result 16";
		      // identify elements with text()
		      List<WebElement> l1= driver.findElements(By.xpath("//*[contains(text(),'result 16')]"));
		      // verify list size
		      if ( l1.size() > 0){
		         System.out.println("Text: " + t + " is present. ");
		      } else {
		         System.out.println("Text: " + t + " is not present. ");
		      }
		   }
	
	//Prefix Service Validation Test
	
	@Test (priority=2)
	public void validatePrefixser() {
		HomePage homepage = new HomePage();
		homepage.PrefixService("Roy");
		
		 String t1 = "result HELLO Roy";
	      // identify elements with text()
	      List<WebElement> l= driver.findElements(By.xpath("//*[contains(text(),'result HELLO Roy')]"));
	      // verify list size
	      if ( l.size() > 0){
	         System.out.println("Text: " + t1 + " is present. ");
	      } else {
	         System.out.println("Text: " + t1 + " is not present. ");
	      }
	   }
	    	
}


