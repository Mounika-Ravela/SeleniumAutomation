package com.WorkFlow.Pages;

import java.util.concurrent.TimeUnit;

import org.apache.http.util.Asserts;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.WorkFlow.TestBase.TestBase;

// Locate WebElemtns on given page (http://ec2-18-133-252-221.eu-west-2.compute.amazonaws.com:3000/#)
// locate webelements of Calculator Service and Prefix Service

public class HomePage extends TestBase{
	
	//Clcik on CalculatorService link
	@FindBy(xpath="//a[contains(text(),'Click to show the Calculator Service')]")
	WebElement CalculatorService; 
	
	//located webElement to validate clicking on CalculatorService link
	@FindBy(xpath="//h2[contains(text(),'CALCULATOR SERVICE')]")
	WebElement CalculatorServiceText; 
	
	
	//located webElement to input value in input text box
	@FindBy(id="calcInput")
	WebElement calcInput;
	
	//located webElement to clcik on click to calucate button.
	@FindBy(id="calcButton1")
	WebElement calcButton;
	
	//located webElement to read results of calucate service results.
	@FindBy(xpath="/html/body/div/div/div/p[2]")
	WebElement calcResult1; 
	
	
	@FindBy(xpath="//a[contains(text(),'Click to show the Prefix Service')]")
	WebElement PrefixSer; 
	
	
	@FindBy(id="prefixInput")
	WebElement prefixInput;
	
	
	@FindBy(id="addPrefixButton")
	WebElement addPrefixButton;
	
	
	@FindBy(id="addPrefixResult")
	WebElement addPrefixResult;
	
	public HomePage() {	
		PageFactory.initElements(driver, this);
	}
	
	
	public void CALCULATORSERVICE(String num) {		
		CalculatorService.click();
	//	CalculatorServiceText.isDisplayed();
		calcInput.clear();
		calcInput.sendKeys(num);
		calcButton.click();
		WebDriverWait wait = new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.visibilityOf(calcResult1)).getText();	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}
	
	
	public void PrefixService(String Text) {
		PrefixSer.click();
		prefixInput.sendKeys(Text);
		addPrefixButton.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String prefre=addPrefixResult.getText();
		System.out.println(prefre);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	}


